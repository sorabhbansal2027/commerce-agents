# Merchant Backend — Deployment Package
## What's inside
This ZIP contains the self-contained Python merchant agent backend backed by
Salesforce OMS. It exposes a streaming FastAPI API consumed by the merchant portal
web app (merchant-web).

## Quick start — local
```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env          # fill in your credentials
uvicorn salesforce.api.main_production:app \
    --app-dir examples \
    --host 0.0.0.0 --port 8000 --reload
# Merchant portal: examples/salesforce/merchant-web (npm run dev)
```

## Docker
```bash
docker build -t merchant-backend .
docker run -p 8000:8000 \
  -e ANTHROPIC_API_KEY=sk-ant-... \
  -e SF_INSTANCE_URL=https://<org>.sandbox.my.salesforce.com \
  -e SF_CLIENT_ID=... \
  -e SF_CLIENT_SECRET=... \
  merchant-backend
```

## API
- `POST /merchant/chat`        — merchant agent streaming turn (SSE)
- `GET  /merchant/overview`    — KPIs, pending changes, alerts
- `POST /merchant/changes/{id}/approve` — approve a staged change
- `GET  /health`               — liveness

## Required env vars
| Variable | Purpose |
|---|---|
| `ANTHROPIC_API_KEY` | Anthropic or proxy API key |
| `SF_INSTANCE_URL`   | Salesforce org base URL |
| `SF_CLIENT_ID`      | Connected App consumer key |
| `SF_CLIENT_SECRET`  | Connected App consumer secret |

## Note on Salesforce Commerce Cloud (account.demandware.com)
This backend is a Python/FastAPI service. Salesforce Commerce Cloud (SFCC/Demandware)
runs JavaScript cartridges in its own runtime — Python cannot execute there directly.
Deployment options:
1. **Railway / ECS / Cloud Run** — deploy this container, point your SFCC cartridge
   at the API URL as an external service call.
2. **AWS ECS** — use `.github/workflows/_deploy-backend-aws.yml` (already in repo);
   fill in ECR/ECS GitHub variables as described in `gemini-aws-deployment.html`.
